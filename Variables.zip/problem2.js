// Define a variable called name with your Name as the assigned value
// Print the value stored in the variable name
// Change the variable to store your father's name
// Print the value stored in the variable name
// Change the variable again to store your mother's name.
// Print the value stored in the variable name

let name = 'Deepak chourasiya';
console.log(name)
name = ' fathername -Aklesh chourasiya';
console.log(name);

name = 'mothersname - Jyoti chourasiya'
console.log(name);
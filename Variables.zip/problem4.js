// Store the name, school, grade, section, rollno and the marks scored by the student in 3 subjects
// Print the report card of the student (You can make it look nice by using some keyboard symbols )

let reportcard= " 🆁🅴 🅿 🅾 🆁🆃  🅲 🅰 🆁 🅳"

let name = 'Deepak chourasiya';
let grade= 'A';
let section = 'Yamuna';
let rollno =  1564;
let englis = 'English = 85 ';
let maths =  'Math =99 ';
let phy =    'Physics = 89';

console.log(reportcard);
console.log(name)
console.log(grade)
console.log(section)
console.log(rollno)
console.log(englis)
console.log(maths)
console.log(phy)